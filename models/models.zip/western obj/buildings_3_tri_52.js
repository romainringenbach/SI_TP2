models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_12_ = function(){
//buildings_3:_Wood_cherry_3_12_
this.vertices = [
362.459991,134.779007,-233.832993, // vertice0
362.145996,134.813004,-233.832993, // vertice1
362.459991,134.779007,-236.214996, // vertice2
362.145996,134.813004,-236.214996 // vertice3
];
this.normals = [
-0.046157,-0.998934,0.0, // normal0
-0.109371,-0.994001,0.0, // normal1
-0.046157,-0.998934,0.0, // normal2
-0.109371,-0.994001,0.0 // normal3
];
this.uv = [
1.0,0.0, // uv0
0.999775,1.0, // uv1
0.000225,0.0, // uv2
0.0,1.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}