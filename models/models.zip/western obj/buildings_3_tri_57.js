models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_15_ = function(){
//buildings_3:_Wood_cherry_3_15_
this.vertices = [
364.432007,135.608002,-236.214005, // vertice0
364.432007,135.608002,-233.832001, // vertice1
364.207001,135.386002,-236.212997, // vertice2
364.207001,135.386002,-233.832001 // vertice3
];
this.normals = [
0.745759,-0.666216,-0.0, // normal0
0.745759,-0.666216,-0.0, // normal1
0.655495,-0.7552,-0.0, // normal2
0.655495,-0.7552,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
6.6e-05,1.0, // uv1
0.999934,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}