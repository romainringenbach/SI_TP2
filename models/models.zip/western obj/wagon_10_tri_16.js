models/western obj/wagon_10_tri_wagon_10:Color_I21 = function(){
//wagon_10:Color_I21
this.vertices = [
-239.733002,49.0639,13.3795, // vertice0
-241.076996,49.0639,13.4701, // vertice1
-240.194,49.0639,13.98, // vertice2
-240.483994,49.0639,14.6792 // vertice3
];
this.normals = [
0.0,1.0,0.0, // normal0
0.0,1.0,0.0, // normal1
0.0,1.0,0.0, // normal2
0.0,1.0,0.0 // normal3
];
this.uv = [
2.86747,20.750799, // uv0
0.630563,19.25, // uv1
2.66989,19.25, // uv2
2.86747,17.749201 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}