models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_6_ = function(){
//buildings_3:_Wood_cherry_3_6_
this.vertices = [
363.955994,135.865997,-359.40799, // vertice0
363.683014,135.707993,-359.40799, // vertice1
363.955994,135.865997,-361.790009, // vertice2
363.683014,135.707993,-361.790009 // vertice3
];
this.normals = [
0.5547,-0.83205,-0.0, // normal0
0.444994,-0.895534,-0.0, // normal1
0.5547,-0.83205,-0.0, // normal2
0.444994,-0.895534,-0.0 // normal3
];
this.uv = [
0.0,1.0, // uv0
2.2e-05,0.0, // uv1
0.999978,1.0, // uv2
1.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}