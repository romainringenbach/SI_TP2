models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_4_6_ = function(){
//buildings_3:_Wood_cherry_4_6_
this.vertices = [
364.915009,136.056,-484.178986, // vertice0
364.915009,136.056,-481.796997, // vertice1
364.789001,135.766998,-484.178009, // vertice2
364.789001,135.766998,-481.79599 // vertice3
];
this.normals = [
0.939846,-0.341599,-0.0, // normal0
0.939846,-0.341599,-0.0, // normal1
0.889085,-0.457742,-0.0, // normal2
0.889085,-0.457742,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
0.000189,1.0, // uv1
0.999811,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}