models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_20_ = function(){
//buildings_3:_Wood_cherry_3_20_
this.vertices = [
364.432007,136.279007,-361.790009, // vertice0
364.432007,136.279007,-359.40799, // vertice1
364.207001,136.057007,-361.790009, // vertice2
364.207001,136.057007,-359.40799 // vertice3
];
this.normals = [
0.745759,-0.666216,-0.0, // normal0
0.745759,-0.666216,-0.0, // normal1
0.655495,-0.7552,-0.0, // normal2
0.655495,-0.7552,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
6.6e-05,1.0, // uv1
0.999934,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}