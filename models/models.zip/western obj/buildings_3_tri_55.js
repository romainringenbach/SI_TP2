models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_23_ = function(){
//buildings_3:_Wood_cherry_3_23_
this.vertices = [
364.789001,136.126999,-236.214005, // vertice0
364.789001,136.126999,-233.832001, // vertice1
364.627014,135.856003,-236.214005, // vertice2
364.627014,135.856003,-233.832001 // vertice3
];
this.normals = [
0.889085,-0.457742,-0.0, // normal0
0.889085,-0.457742,-0.0, // normal1
0.824041,-0.56653,-0.0, // normal2
0.824041,-0.56653,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
0.00015,1.0, // uv1
0.99985,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}