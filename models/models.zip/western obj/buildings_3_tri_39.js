models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_4_ = function(){
//buildings_3:_Wood_cherry_3_4_
this.vertices = [
362.774994,135.455994,-359.408997, // vertice0
362.459991,135.449997,-359.408997, // vertice1
362.774994,135.455994,-361.790009, // vertice2
362.459991,135.449997,-361.790985 // vertice3
];
this.normals = [
0.080575,-0.996749,0.0, // normal0
-0.046157,-0.998934,0.0, // normal1
0.080575,-0.996749,0.0, // normal2
-0.046157,-0.998934,0.0 // normal3
];
this.uv = [
0.0,1.0, // uv0
0.000189,0.0, // uv1
0.999811,1.0, // uv2
1.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}