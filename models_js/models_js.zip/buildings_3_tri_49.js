models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_7_ = function(){
//buildings_3:_Wood_cherry_3_7_
this.vertices = [
365.003998,137.389999,-361.790985, // vertice0
365.003998,137.389999,-359.410004, // vertice1
364.915009,137.087997,-361.790985, // vertice2
364.915009,137.087997,-359.408997 // vertice3
];
this.normals = [
0.959605,-0.28135,-0.0, // normal0
0.959605,-0.28135,-0.0, // normal1
0.939846,-0.341599,-0.0, // normal2
0.939846,-0.341599,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
0.000225,1.0, // uv1
0.999775,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}