models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_4_2_ = function(){
//buildings_3:_Wood_cherry_4_2_
this.vertices = [
364.207001,135.026001,-484.177002, // vertice0
364.207001,135.026001,-481.795013, // vertice1
363.955994,134.835007,-484.177002, // vertice2
363.955994,134.835007,-481.795013 // vertice3
];
this.normals = [
0.655495,-0.7552,-0.0, // normal0
0.655495,-0.7552,-0.0, // normal1
0.5547,-0.83205,-0.0, // normal2
0.5547,-0.83205,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
2.2e-05,1.0, // uv1
0.999978,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}