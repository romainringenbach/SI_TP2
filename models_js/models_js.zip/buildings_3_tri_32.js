models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_4_3_ = function(){
//buildings_3:_Wood_cherry_4_3_
this.vertices = [
364.432007,135.248001,-484.177002, // vertice0
364.432007,135.248001,-481.79599, // vertice1
364.207001,135.026001,-484.177002, // vertice2
364.207001,135.026001,-481.795013 // vertice3
];
this.normals = [
0.745759,-0.666216,-0.0, // normal0
0.745759,-0.666216,-0.0, // normal1
0.655495,-0.7552,-0.0, // normal2
0.655495,-0.7552,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
6.6e-05,1.0, // uv1
0.999934,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}