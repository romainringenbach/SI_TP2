models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_9_ = function(){
//buildings_3:_Wood_cherry_3_9_
this.vertices = [
363.391998,135.585999,-359.40799, // vertice0
363.088013,135.501007,-359.40799, // vertice1
363.391998,135.585999,-361.790009, // vertice2
363.088013,135.501007,-361.790009 // vertice3
];
this.normals = [
0.328139,-0.94463,0.0, // normal0
0.206012,-0.97855,0.0, // normal1
0.328139,-0.94463,0.0, // normal2
0.206012,-0.97855,0.0 // normal3
];
this.uv = [
0.0,1.0, // uv0
0.000109,0.0, // uv1
0.999891,1.0, // uv2
1.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}