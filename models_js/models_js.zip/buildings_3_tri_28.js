models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_4_1_ = function(){
//buildings_3:_Wood_cherry_4_1_
this.vertices = [
363.391998,134.554993,-481.79599, // vertice0
363.088013,134.470001,-481.79599, // vertice1
363.391998,134.554993,-484.177002, // vertice2
363.088013,134.470001,-484.178009 // vertice3
];
this.normals = [
0.328139,-0.94463,0.0, // normal0
0.206012,-0.97855,0.0, // normal1
0.328139,-0.94463,0.0, // normal2
0.206012,-0.97855,0.0 // normal3
];
this.uv = [
0.0,1.0, // uv0
0.000109,0.0, // uv1
0.999891,1.0, // uv2
1.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}