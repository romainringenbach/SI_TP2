models/western obj/buildings_3_tri_buildings_3:_Wood_cherry_3_2_ = function(){
//buildings_3:_Wood_cherry_3_2_
this.vertices = [
364.915009,137.087997,-361.790985, // vertice0
364.915009,137.087997,-359.408997, // vertice1
364.789001,136.798004,-361.790009, // vertice2
364.789001,136.798004,-359.408997 // vertice3
];
this.normals = [
0.939846,-0.341599,-0.0, // normal0
0.939846,-0.341599,-0.0, // normal1
0.889085,-0.457742,-0.0, // normal2
0.889085,-0.457742,-0.0 // normal3
];
this.uv = [
1.0,1.0, // uv0
0.000189,1.0, // uv1
0.999811,0.0, // uv2
0.0,0.0 // uv3
];
this.index = [
0,
1,
2,
2,
1,
3,
];
}